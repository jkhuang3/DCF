from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from locators.locators import Locators
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException

class statistics():
    def __init__(self, driver, tckr):
        self.driver = driver
        self.tckr = tckr

    def move_to_statistics(self):
        try:
            search_bar = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.search_bar_id))
            )

            search_bar.clear()
            search_bar.send_keys(self.tckr)
            search_bar.send_keys(Keys.ENTER)

            statistics_link = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.statistics_linked_text))
            )

            statistics_link.click()

        except NoSuchElementException:
            self.driver.quit()

    def get_statistics(self):
        exit_multiple = float(WebDriverWait(self.driver, 5).until(
            EC.presence_of_element_located((By.XPATH, Locators.em_current_xpath))
        ).text.replace(',', ''))

        shares = float(WebDriverWait(self.driver, 5).until(
            EC.presence_of_element_located((By.XPATH, Locators.shares_xpath))
        ).text[:-1]) * 1000000000

        return exit_multiple, shares