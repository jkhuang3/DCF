from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from locators.locators import Locators
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException


class balance_sheet():
    def __init__(self, driver, tckr):
        self.driver = driver
        self.tckr = tckr

    def move_to_balance_sheet(self):
        try:
            button = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.x_out))
            )
            button.click()

            search_bar = self.driver.find_element(by=By.XPATH, value=Locators.search_bar_id)

            search_bar.clear()
            search_bar.send_keys(self.tckr)
            search_bar.send_keys(Keys.ENTER)

            financial_link = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.financials_linked_text))
            )

            financial_link.click()

            balance_sheet_link = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.LINK_TEXT, Locators.balance_sheet_linked_text))
            )

            balance_sheet_link.click()

        except NoSuchElementException:
            self.driver.quit()

    def get_balance_sheet_values(self):
        try:

            total_assets_button = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.total_assets_button_xpath))
            )
            total_assets_button.click()

            current_assets_button = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.current_assets_button_xpath))
            )
            current_assets_button.click()

            receivables_assets_button = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.receivables_button_xpath))
            )
            receivables_assets_button.click()

            total_liabilites_button = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.total_liabilites_xpath))
            )
            total_liabilites_button.click()

            current_liabilities_button = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.current_liabilites_xpath))
            )
            current_liabilities_button.click()

            payables_accrued_expeneses_button = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.payables_accrued_expenses_xpath))
            )
            payables_accrued_expeneses_button.click()

            payables_button = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.payables_xpath))
            )
            payables_button.click()

            current_nwc = int(self.driver.find_element(by=By.XPATH, value=Locators.nwc_current_xpath).text.replace(',', ''))

            previous_nwc = int(
                self.driver.find_element(by=By.XPATH, value=Locators.nwc_previous_xpath).text.replace(',', ''))

            ar_current = int(self.driver.find_element(by=By.XPATH, value=Locators.ar_current_xpath).text.replace(',', ''))
            ar_previous = int(self.driver.find_element(by=By.XPATH, value=Locators.ar_previous_xpath).text.replace(',', ''))
            inventory_current = int(self.driver.find_element(by=By.XPATH, value=Locators.inventory_current_xpath).text.replace(',', ''))
            inventory_previous = int(self.driver.find_element(by=By.XPATH, value=Locators.inventory_previous_xpath).text.replace(',', ''))
            cash = int(self.driver.find_element(by=By.XPATH, value=Locators.cash_xpath).text.replace(',', ''))
            net_debt = int(self.driver.find_element(by=By.XPATH, value=Locators.net_debt_xpath).text.replace(',', ''))
            ap_current = int(self.driver.find_element(by=By.XPATH, value=Locators.ap_current_xpath).text.replace(',', ''))
            ap_previous = int(self.driver.find_element(by=By.XPATH, value=Locators.ap_previous_xpath).text.replace(',', ''))

            return current_nwc, previous_nwc, ar_current, ar_previous, inventory_current, inventory_previous, cash, net_debt, ap_current, ap_previous

        except NoSuchElementException:
            self.driver.quit()