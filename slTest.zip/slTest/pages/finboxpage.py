from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from locators.locators import Locators


class wacc_page():
    def __init__(self, driver, tckr):
        self.driver = driver
        self.tckr = tckr

    def search_stock(self):
        ##place an explicit wait here, I think that it is moving too fast 😅

        try:
            self.driver.find_element(by=By.CLASS_NAME, value=Locators.search_bar_enable).click()

            search_bar = self.driver.find_element(by=By.XPATH, value=Locators.search_bar_input)
            search_bar.clear()
            search_bar.send_keys(self.tckr)

            stock_pick = WebDriverWait(self.driver, 1).until(
                EC.presence_of_element_located((By.XPATH, Locators.stock))
            )

            stock_pick.click()

            self.driver.find_element(by=By.XPATH, value=Locators.wacc_link_xpath).click()

            return float(self.driver.find_element(by=By.XPATH, value=Locators.wacc).text[:-1])

        finally:
            self.driver.quit()