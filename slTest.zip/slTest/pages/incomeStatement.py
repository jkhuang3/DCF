from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from locators.locators import Locators
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException



class income_statement():
    def __init__(self, driver, tckr):
        self.driver = driver
        self.tckr = tckr

    #If I am grouping all these elements together, I should only need one to grab all the data
    def move_to_income_statement(self):
        try:

            search_bar = self.driver.find_element(by=By.XPATH, value=Locators.search_bar_id)

            search_bar.clear()
            search_bar.send_keys(self.tckr)
            search_bar.send_keys(Keys.ENTER)

            financial_link = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.financials_linked_text))
            )

            financial_link.click()

        except NoSuchElementException:
            self.driver.quit()

    def calculate_tax_rate(self):
        try:
            tax_provision = int(WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.tax_provision_xpath))
            ).text.replace(',', ''))
            pretax_income = int(WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.pretax_income_xpath))
            ).text.replace(',', ''))

            return tax_provision / pretax_income
        except NoSuchElementException:
            self.driver.quit()

    def get_income_statement_values(self):
        try:
            current_revenue = int(WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.revenue_current_xpath))
            ).text.replace(',', ''))

            previous_revenue = int(WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.revenue_previous_xpath))
            ).text.replace(',', ''))

            current_cogs = int(WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.cogs_current_xpath))
            ).text.replace(',', ''))

            current_gp = int(WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.gp_current_xpath))
            ).text.replace(',', ''))

            current_ebitda = int(WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.ebitda_current_xpath))
            ).text.replace(',', ''))

            current_ebit = int(WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.ebit_current_xpath))
            ).text.replace(',', ''))

            return current_revenue, previous_revenue, current_cogs, current_gp, current_ebitda, current_ebit

        except NoSuchElementException:
            self.driver.quit()