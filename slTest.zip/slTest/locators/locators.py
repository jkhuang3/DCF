class Locators():
#To get the WACC, I am veering off Yahoo Finance and instead moving to finbox
    yf_base_url = "https://finance.yahoo.com/"
    search_bar_id = "//input[@id='yfin-usr-qry']"
    financials_linked_text = "//ul[@role='tablist']/li[8]/a"
    x_out = "//button[@aria-label='Close modal']"
    statistics_linked_text = "//li[@data-test='STATISTICS']"

# These are the values that I would need to obtain from the statement of cash flows
# These are the values that I need to get the Effective Tax rate

# We are using this page to find the EV/EBIDTA multiple
    em_current_xpath = "//tbody/tr[9]/td[2]"
    shares_xpath = "//section[@data-test='qsp-statistics']/div[3]/div[2]/div/div[2]/div/div/table/tbody/tr[4]/td[2]"