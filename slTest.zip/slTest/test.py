from selenium import webdriver
from locators.locators import Locators
from pages.balanceSheet import balance_sheet
from pages.cashFlows import cash_flows
from pages.incomeStatement import income_statement
from pages.statistics import statistics


#Finbox page
bs_driver = webdriver.Chrome()

bs_driver.get(Locators.yf_base_url)

bs = statistics(bs_driver, "nvda")
#Obtain WACC value
bs.move_to_statistics()

print(bs.get_statistics())
# current_wacc = wacc.obtain_wacc()