from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from locators.locators import Locators
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException

class cash_flows():
    def __init__(self, driver, tckr):
        self.driver = driver
        self.tckr = tckr

    def move_to_cash_flows(self):
        try:
            # button = WebDriverWait(self.driver, 5).until(
            #     EC.presence_of_element_located((By.XPATH, Locators.x_out))
            # )
            # button.click()

            search_bar = self.driver.find_element(by=By.XPATH, value=Locators.search_bar_id)

            search_bar.clear()
            search_bar.send_keys(self.tckr)
            search_bar.send_keys(Keys.ENTER)

            financial_link = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.financials_linked_text))
            )

            financial_link.click()

            balance_sheet_link = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.LINK_TEXT, Locators.cash_flows_linked_text))
            )

            balance_sheet_link.click()

        except NoSuchElementException:
            self.driver.quit()


    def get_cash_flow_values(self):

        try:
            operating_cash_flow_button = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, Locators.operating_cash_flow_button))
            )

            operating_cash_flow_button.click()

            capex = int(self.driver.find_element(by=By.XPATH, value=Locators.capex_current_xpath).text.replace(',', ''))

        except NoSuchElementException:
            self.driver.quit()

        return capex