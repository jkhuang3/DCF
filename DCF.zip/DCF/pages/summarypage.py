from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from locators.locators import Locators
from selenium.webdriver.common.keys import Keys

class summary_page():
    def __init__(self, driver, tckr):
        self.driver = driver
        self.tckr = tckr

    def move_to_tckr(self):
        search_bar = self.driver.find_element(by=By.XPATH, value=Locators.search_bar_id)

        actions = ActionChains(self.driver)
        actions.move_to_element(search_bar)
        search_bar.clear()
        actions.send_keys(self.tckr)
        actions.send_keys(Keys.ENTER) #Need to do this with the other move-tos

        actions.perform()

    def get_last_price(self):
        return int(self.driver.find_element(by=By.XPATH, value=Locators.last_price_xpath).text.replace(',', ''))

