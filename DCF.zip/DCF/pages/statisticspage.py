from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from locators.locators import Locators

class statistics():
    def __init__(self, driver, tckr):
        self.driver = driver
        self.tckr = tckr

    def move_to_statistics(self):
        search_bar = self.driver.find_element(by=By.XPATH, value=Locators.search_bar_id)
        statistics_link = self.driver.find_element(by=By.LINK_TEXT, value=Locators.statistics_link)

        actions = ActionChains(self.driver)
        actions.move_to_element(search_bar)
        search_bar.clear()
        actions.send_keys(self.tckr)
        actions.send_keys(Keys.ENTER)
        actions.move_to_element(statistics_link).click()

        actions.perform()

    def get_statistics(self):
        exit_multiple = int(self.driver.find_element(by=By.XPATH, value=Locators.em_current_xpath).text.replace(',', ''))
        shares = int(self.driver.find_element(by=By.XPATH, value=Locators.shares_xpath).text.replace(',', ''))

        return exit_multiple, shares