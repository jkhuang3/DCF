class Locators():

    #To get effective tax rate, we are going to use some of the fields listed in Yahoo Finance

    #This is to login and find the search bar in Yahoo Finance
    #I have to change the locators here to to full URL
    yf_base_url = "https://finance.yahoo.com/"
    search_bar_id = "//input[@id='yfin-usr-qry']"
    financials_linked_text = "//ul[@role='tablist']/li[8]/a"
    x_out = "//button[@aria-label='Close modal']"
    last_price_xpath = "//fin-streamer[@data-test='qsp-price']"

    tax_provision_xpath = "//div[@class='Pos(r)']//div[@data-test='fin-row'][9]//div[@data-test='fin-col'][1]//span"
    pretax_income_xpath = "//div[@class='Pos(r)']//div[@data-test='fin-row'][8]//div[@data-test='fin-col'][1]//span"

    # These are the values that I can find on the Income Statement to calculate the DCF
    revenue_current_xpath = "//div[@class='Pos(r)']//div[@data-test='fin-col'][1]//span"
    revenue_previous_xpath = "//div[@class='Pos(r)']//div[@data-test='fin-col'][2]//span"
    cogs_current_xpath = "//div[@class='Pos(r)']//div[@data-test='fin-row'][2]//div[@data-test='fin-col'][1]//span"
    gp_current_xpath = "//div[@class='Pos(r)']//div[@data-test='fin-row'][3]//div[@data-test='fin-col'][1]//span"
    ebitda_current_xpath = "//div[@class='Pos(r)']//div[@data-test='fin-row'][24]//div[@data-test='fin-col'][1]//span"
    ebit_current_xpath = "//div[@class='Pos(r)']//div[@data-test='fin-row'][23]//div[@data-test='fin-col'][1]//span"

    #These are the values that I would need to obtain from the balance sheet

    balance_sheet_linked_text = "Balance Sheet"

    nwc_current_xpath = "//div[@class='D(tbrg)']/div[8]//div[@data-test='fin-col']/span"
    nwc_previous_xpath = "//div[@class='D(tbrg)']/div[8]//div[@data-test='fin-col'][2]/span"

    total_assets_button_xpath = "//div[@class='D(tbrg)']//div[@title='Total Assets']/button"
    current_assets_button_xpath = "//div[@class='D(tbrg)']//button[@aria-label='Current Assets']"
    receivables_button_xpath = "//div[@class='D(tbrg)']//button[@aria-label='Receivables']"

    ar_current_xpath = "//section[@data-test='qsp-financial']/div[4]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[2]/span"
    ar_previous_xpath = "//section[@data-test='qsp-financial']/div[4]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[3]/span"
    inventory_current_xpath = "//section[@data-test='qsp-financial']/div[4]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[3]/div[1]/div[2]/span"
    inventory_previous_xpath = "//section[@data-test='qsp-financial']/div[4]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[3]/div[1]/div[3]/span"

    # Wait, don't I need to open things here too
    total_liabilites_xpath = "//div[@class='D(tbrg)']//button[@aria-label='Total Liabilities Net Minority Interest']"
    current_liabilites_xpath = "//div[@class='D(tbrg)']//button[@aria-label='Current Liabilities']"
    payables_accrued_expenses_xpath = "//div[@class='D(tbrg)']//button[@aria-label='Payables And Accrued Expenses']"
    payables_xpath = "//div[@class='D(tbrg)']//button[@aria-label='Payables']"

    ap_current_xpath = "//section[@data-test='qsp-financial']/div[4]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/span"
    ap_previous_xpath = "//section[@data-test='qsp-financial']/div[4]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/span"
    cash_xpath = "//section[@data-test='qsp-financial']/div[4]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/span"
    net_debt_xpath = "//section[@data-test='qsp-financial']/div[4]/div/div/div[2]/div[12]/div[1]/div[2]/span"

    #These are the values that I would need to obtain from the statement of cash flows
    cash_flows_linked_text = "Cash Flow"
    operating_cash_flow_button = "//button[@aria-label='Operating Cash Flow']"
    capex_current_xpath = "//div[@class='D(tbrg)']/div[7]//div[@data-test='fin-col'][1]/span"

    #We are using this page to find the EV/EBIDTA multiple
    statistics_link = "Statistics"
    em_current_xpath = "//tbody/tr[9]/td[2]"
    shares_xpath = "//section[@data-test='qsp-statistics']/div[3]/div[2]/div/div[2]/div/div/table/tbody/tr[4]/td[2]"

    #To get the WACC, I am veering off Yahoo Finance and instead moving to finbox
    finbox_base_url = "https://www.alphaspread.com/security"
    search_bar_enable = "fake-search-input"
    search_bar_input = "//input[@placeholder='Search stocks and companies...']"
    stock = "//tbody/tr[1]"  # This will be clicked
    wacc_link_xpath = "//div[@class='ui two column relaxed stackable no-margin grid']/div[8]"
    wacc = "//span[@field='capm_discount_rate']"





