from selenium import webdriver

from pages.summarypage import summary_page
from pages.finboxpage import wacc_page
from pages.statisticspage import statistics
from pages.incomestatementpage import income_statement
from pages.balancesheetpage import balance_sheet
from pages.cashflowpage import cash_flows
from locators.locators import Locators


#here are all the values that I need to obtain:
#WACC, ✅
# ETR, ✅
# RevenuePrevious,✅
# RevenueCurrent,✅
# COGSCurrent,✅
# GPCurrent, ✅
# EBITDACurrent, ✅
# DACurrent, This is just EBIT - EBITDA ✅
# EBITCurrent,✅
# NWCPrevious, ✅
# NWCCurrent, ✅
# CapexCurrent, ✅
# ARPrevious, ✅
# ARCurrent, ✅
# InventoryPrevious, ✅
# InventoryCurrent, ✅
# APPrevious, ✅
# APCurrent, ✅
# Cash, ✅
# EM, ✅
# NetDebt, ✅
# Shares, ✅
# LastPrice

def dataGrab(tckr):
    #Load the driver and get the stock ticker

    #Finbox page
    finbox_driver = webdriver.Chrome()
    finbox_driver.implicitly_wait(15)
    finbox_driver.get(Locators.finbox_base_url)

    #yf pages
    balance_sheet_driver = webdriver.Chrome()
    balance_sheet_driver.implicitly_wait(15)
    balance_sheet_driver.get(Locators.yf_base_url)

    cash_flow_driver = webdriver.Chrome()
    cash_flow_driver.implicitly_wait(15)
    cash_flow_driver.get(Locators.yf_base_url)

    income_statement_driver = webdriver.Chrome()
    income_statement_driver.implicitly_wait(15)
    income_statement_driver.get(Locators.yf_base_url)

    statistics_driver = webdriver.Chrome()
    statistics_driver.implicitly_wait(15)
    statistics_driver.get(Locators.yf_base_url)

    summary_driver = webdriver.Chrome()
    summary_driver.implicitly_wait(15)
    summary_driver.get(Locators.yf_base_url)


    #Create objects for each of the pages
    wacc = wacc_page(finbox_driver, tckr)
    balanceSheet = balance_sheet(balance_sheet_driver, tckr)
    cashFlow = cash_flows(cash_flow_driver, tckr)
    incomeStatement = income_statement(income_statement_driver, tckr)
    multiples = statistics(statistics_driver, tckr)
    summary = summary_page(summary_driver, tckr)

    #Obtain WACC value
    current_wacc = wacc.search_stock()

    #obtain balance sheet values
    balanceSheet.move_to_balance_sheet()
    current_nwc, previous_nwc, ar_current, ar_previous, inventory_current, inventory_previous, cash, net_debt, ap_current, ap_previous = balanceSheet.get_balance_sheet_values()

    #obtain cash flow values
    cashFlow.move_to_cash_flows()
    capex = cashFlow.get_cash_flow_values()

    #obtain income statement values
    incomeStatement.move_to_income_statement()
    ETR = incomeStatement.calculate_tax_rate()
    current_revenue, previous_revenue, current_cogs, current_gp, current_ebitda, current_ebit = incomeStatement.get_income_statement_values()

    #obtain summary page values
    summary.move_to_tckr()
    last_price = summary.get_last_price()

    #obtain statistics
    multiples.move_to_statistics()
    ev_ebitda, shares = multiples.get_statistics()

    finbox_driver.quit()
    balance_sheet_driver.quit()
    income_statement_driver.quit()
    cash_flow_driver.quit()
    statistics_driver.quit()
    summary_driver.quit()


    return ETR, current_wacc, current_nwc, previous_nwc, ar_current, ar_previous, inventory_current, inventory_previous, cash, net_debt, ap_current, ap_previous, capex, current_revenue, previous_revenue, current_cogs, current_gp, current_ebitda, current_ebit, last_price, ev_ebitda, shares










