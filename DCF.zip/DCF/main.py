import DCF as dcf


if __name__ == "__main__":
    tickerInput = input("Please enter a ticker: ")
    dateInput = input("Please enter a date in YYYYMMDD: ")
    modeInput = input("Please enter a mode (Perpetuity or Exit Multiple): ")
    times = input("Please specify a time period: ")

    print(dcf.DCF(modeInput, times, tickerInput))