from selenium.webdriver.common.by import By
from locators.locators import Locators

class homepage():
    def __init__(self, driver):
        self.driver = driver

    def click_dropdown(self):
        self.driver.find_element(by=By.CLASS_NAME, value=Locators.dropdown_class).click()

    def click_logout(self):
        self.driver.find_element(by=By.LINK_TEXT, value=Locators.logout_linked_text).click()