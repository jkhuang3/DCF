from selenium.webdriver.common.by import By
#Hold all the objects that you are using for the documentation

class Locators():

    #Login page objects
    username_textbox_name = "username"
    password_textbox_name = "password"
    login_button_tagName = "button"


    #Home page objects
    dropdown_class = "oxd-userdropdown"
    logout_linked_text = "Logout"