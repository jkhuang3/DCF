from selenium import webdriver
import unittest
from pages.loginpage import loginpage
from pages.homepage import homepage
import HtmlTestRunner

class LoginTest(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.implicitly_wait(10)

    def test_login_valid(self):
        URL = "https://opensource-demo.orangehrmlive.com/"
        self.driver.get(URL)

        login = loginpage(self.driver)
        login.enter_username("Admin")
        login.enter_password("admin123")
        login.click_login()

        home = homepage(self.driver)
        home.click_dropdown()
        home.click_logout()

        # self.driver.find_element(by=By.NAME, value="username").send_keys("Admin")
        # self.driver.find_element(by=By.NAME, value="password").send_keys("admin123")
        # self.driver.find_element(by=By.TAG_NAME, value="button").click()
        # self.driver.find_element(by=By.CLASS_NAME, value="oxd-userdropdown").click()
        # self.driver.find_element(by=By.LINK_TEXT, value="Logout").click()

    def tearDown(self):
        self.driver.quit()
        print("Test Completed")


if __name__ == "__main__":
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output="/Users/jonathanhuang/PycharmProjects/Webscraper/reports"))
